/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seungnle <seungnle@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/18 15:51:22 by seungnle          #+#    #+#             */
/*   Updated: 2021/12/09 20:55:25 by seungnle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

static void	pickup_fork(t_philo *philo)
{
	if (philo->info->num_of_philo == 1)
	{
		print_philo_msg(philo, "has taken a fork");
		while (philo->info->time_to_die >= \
		 get_time() - philo->last_time_to_eat)
			usleep(5000);
		return ;
	}
	else
	{
		pthread_mutex_lock(philo->right);
		print_philo_msg(philo, "has taken a fork");
		pthread_mutex_lock(philo->left);
		print_philo_msg(philo, "has taken a fork");
	}
}

static void	eating(t_philo *philo)
{
	pthread_mutex_lock(&philo->check_mutex);
	if (!philo->info->finish)
	{
		print_philo_msg(philo, "is eating");
		philo->last_time_to_eat = get_time();
	}
	philo->num_of_eat += 1;
	if (philo->num_of_eat == philo->info->num_of_must_eat)
		philo->info->num_of_eat_finish_philo += 1;
	while (philo->info->time_to_eat > get_time() - philo->last_time_to_eat)
		usleep(1000);
	pthread_mutex_unlock(philo->left);
	pthread_mutex_unlock(philo->right);
	pthread_mutex_unlock(&philo->check_mutex);
	philo->last_time_to_sleep = get_time();
}

static void	sleeping(t_philo *philo)
{
	print_philo_msg(philo, "is sleeping");
	while (philo->info->time_to_sleep > get_time() - philo->last_time_to_sleep)
		usleep(1000);
}

static void	thinking(t_philo *philo)
{
	print_philo_msg(philo, "is thinking");
}

void	*philo(void *argv)
{
	t_philo	*philo;

	philo = argv;
	if (philo->info->num_of_philo == 1)
	{
		pickup_fork(philo);
		return (0);
	}
	if (philo->n % 2 == 0)
		while (philo->info->time_to_eat > get_time() - philo->last_time_to_eat)
			usleep(1000);
	while (!philo->info->finish)
	{
		pickup_fork(philo);
		eating(philo);
		sleeping(philo);
		thinking(philo);
	}
	return (0);
}
