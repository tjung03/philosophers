/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitor.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seungnle <seungnle@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/19 00:53:57 by seungnle          #+#    #+#             */
/*   Updated: 2021/12/09 21:02:56 by seungnle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

void	*monitor_each_must_eat(void *argv)
{
	t_info	*info;

	info = argv;
	while (!info->finish)
	{
		if (info->num_of_eat_finish_philo == info->num_of_philo)
			info->finish = 1;
	}
	return (0);
}

void	*monitor(void *argv)
{
	t_philo			*philos;
	t_philo			*philo;
	long long		ms;
	int				i;

	philos = argv;
	philo = &philos[0];
	i = 0;
	while (!philo->info->finish)
	{
		pthread_mutex_lock(&philo->check_mutex);
		ms = get_time() - philo->last_time_to_eat;
		if (ms > philo->info->time_to_die && philo->info->finish == 0)
		{
			print_philo_msg(philo, "died");
			philo->info->finish = 1;
		}
		pthread_mutex_unlock(&philo->check_mutex);
		++i;
		if (i == philo->info->num_of_philo)
			i = 0;
		philo = &philos[i];
		usleep(1000);
	}
	return (0);
}
